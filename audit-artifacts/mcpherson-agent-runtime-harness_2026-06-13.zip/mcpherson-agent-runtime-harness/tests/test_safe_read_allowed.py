def test_safe_read_allowed(harness, req_factory):
    resp = harness.process_request(req_factory(mode="local_fake"))
    assert resp.allowed is True
    assert resp.blocked_reason is None
    assert resp.fake_tool_result["fictional_marker"]
