def test_approval_required_allowed_with_fake_approval(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="dry_run", message="mark pilot ready",
        tool="mark_pilot_ready", approval=True))
    assert resp.allowed is True
    assert resp.trace_event["approval_required"] is True
    assert resp.trace_event["approval_present"] is True
