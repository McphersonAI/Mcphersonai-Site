def test_fake_write_allowed_in_dry_run(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="dry_run", message="create a shift note about prep",
        tool="create_shift_note"))
    assert resp.allowed is True
    assert resp.fake_tool_result["record_type"] == "shift_note"
    assert resp.fake_tool_result["text"].startswith("[FAKE]")
