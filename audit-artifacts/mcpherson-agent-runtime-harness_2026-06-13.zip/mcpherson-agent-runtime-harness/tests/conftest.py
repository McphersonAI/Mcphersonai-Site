import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from mcpherson_runtime_harness import RuntimeHarness, RuntimeRequest  # noqa: E402


@pytest.fixture
def repo_root():
    return ROOT


@pytest.fixture
def harness():
    return RuntimeHarness()


@pytest.fixture
def scenarios(repo_root):
    data = json.loads((repo_root / "data" / "fake_scenarios.json").read_text())
    return data["scenarios"]


def make_request(mode="local_fake", message="show me the store profile",
                 tool="read_store_profile", approval=False, kill=False):
    return RuntimeRequest(
        fake_pilot_id="pilot-fake-001",
        fake_store_name="Sample Bagel Shop #000 (FICTIONAL)",
        fake_operator_role="gm",
        incoming_message=message,
        mode=mode,
        requested_tool=tool,
        approval_present=approval,
        kill_switch_active=kill,
    )


@pytest.fixture
def req_factory():
    return make_request
