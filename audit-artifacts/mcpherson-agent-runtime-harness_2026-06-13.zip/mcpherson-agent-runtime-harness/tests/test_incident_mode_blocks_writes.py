def test_incident_mode_blocks_writes(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="incident_mode", message="create a shift note",
        tool="create_shift_note"))
    assert resp.allowed is False
    assert "incident" in resp.blocked_reason


def test_incident_mode_allows_incident_read_only(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="incident_mode", message="show me the store profile",
        tool="read_store_profile"))
    assert resp.allowed is True


def test_incident_mode_blocks_outbound(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="incident_mode", message="text customer", tool="send_text_message"))
    assert resp.allowed is False
