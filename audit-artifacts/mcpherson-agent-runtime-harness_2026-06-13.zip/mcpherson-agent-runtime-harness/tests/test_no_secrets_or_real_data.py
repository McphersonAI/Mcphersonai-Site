"""Verify no secrets and no real client data anywhere in the repo."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

SECRET_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9]{20,}"),          # API-key shapes
    re.compile(r"AKIA[0-9A-Z]{16}"),              # AWS
    re.compile(r"ghp_[A-Za-z0-9]{30,}"),          # GitHub
    re.compile(r"xox[bpars]-[A-Za-z0-9-]{10,}"),  # Slack
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
]

SCAN_SUFFIXES = {".py", ".json", ".md", ".txt", ".example", ".gitignore"}
SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", "dist", "exports"}


def iter_files():
    for p in ROOT.rglob("*"):
        if p.is_file() and not (set(p.parts) & SKIP_DIRS):
            if p.suffix in SCAN_SUFFIXES or p.name in {".gitignore", ".env.example"}:
                yield p


def test_no_secret_shapes_present():
    for p in iter_files():
        text = p.read_text(errors="ignore")
        for pat in SECRET_PATTERNS:
            assert not pat.search(text), f"secret-shaped string in {p}"


def test_env_example_has_no_values():
    env = (ROOT / ".env.example").read_text()
    for line in env.splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            _, value = line.split("=", 1)
            assert value.strip() in ("", '""', "''"), \
                f".env.example must not contain values: {line}"


def test_data_files_marked_fictional():
    marker = "FICTIONAL"
    for p in (ROOT / "data").glob("*.json"):
        assert marker in p.read_text(), f"{p.name} missing fictional marker"
