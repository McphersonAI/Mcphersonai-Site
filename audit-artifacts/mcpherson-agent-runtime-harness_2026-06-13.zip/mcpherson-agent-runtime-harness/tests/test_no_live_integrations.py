"""Verify no live integrations: source code never imports network/db modules."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "mcpherson_runtime_harness"

FORBIDDEN_IMPORTS = [
    "requests", "httpx", "aiohttp", "urllib.request", "socket",
    "telegram", "telethon", "sqlite3", "psycopg", "langfuse",
    "anthropic", "openai", "mcp",
]


def test_no_live_integration_imports():
    pattern = re.compile(
        r"^\s*(import|from)\s+(" + "|".join(map(re.escape, FORBIDDEN_IMPORTS)) + r")\b",
        re.MULTILINE)
    for py in SRC.rglob("*.py"):
        text = py.read_text()
        match = pattern.search(text)
        assert match is None, f"forbidden import in {py.name}: {match.group(0)!r}"


def test_no_urls_in_source():
    for py in SRC.rglob("*.py"):
        text = py.read_text()
        assert "http://" not in text and "https://" not in text, \
            f"URL found in {py.name}"
