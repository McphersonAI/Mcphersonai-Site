REQUIRED_RESPONSE_FIELDS = [
    "request_id", "fake_pilot_id", "mode", "intent", "allowed",
    "blocked_reason", "requested_tool", "fake_tool_result", "trace_event",
    "final_message", "fictional_marker",
]


def test_response_contract_allowed(harness, req_factory):
    d = harness.process_request(req_factory()).to_dict()
    for f in REQUIRED_RESPONSE_FIELDS:
        assert f in d, f"missing {f}"
    assert d["allowed"] is True and d["blocked_reason"] is None


def test_response_contract_blocked(harness, req_factory):
    d = harness.process_request(req_factory(
        mode="human_only")).to_dict()
    for f in REQUIRED_RESPONSE_FIELDS:
        assert f in d, f"missing {f}"
    assert d["allowed"] is False and d["blocked_reason"]
    assert d["fake_tool_result"] is None
