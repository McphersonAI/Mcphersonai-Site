REQUIRED_TRACE_FIELDS = [
    "event_id", "timestamp", "request_id", "fake_pilot_id", "mode", "intent",
    "requested_tool", "governance_decision", "mcp_decision", "final_decision",
    "reason", "approval_required", "approval_present", "fictional_marker",
]


def test_trace_event_created_for_allowed(harness, req_factory):
    resp = harness.process_request(req_factory())
    for f in REQUIRED_TRACE_FIELDS:
        assert f in resp.trace_event, f"missing {f}"
    assert resp.trace_event["final_decision"] == "allowed"
    assert resp.trace_event in harness.local_event_log


def test_trace_event_created_for_blocked(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="dry_run", message="text customer", tool="send_text_message"))
    for f in REQUIRED_TRACE_FIELDS:
        assert f in resp.trace_event, f"missing {f}"
    assert resp.trace_event["final_decision"] == "blocked"
    assert resp.trace_event in harness.local_event_log
