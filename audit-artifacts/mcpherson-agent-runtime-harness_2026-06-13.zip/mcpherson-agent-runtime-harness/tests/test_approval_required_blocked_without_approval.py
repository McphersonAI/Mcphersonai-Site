def test_approval_required_blocked_without_approval(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="dry_run", message="mark pilot ready",
        tool="mark_pilot_ready", approval=False))
    assert resp.allowed is False
    assert "approval" in resp.blocked_reason
    assert resp.fake_tool_result is None
