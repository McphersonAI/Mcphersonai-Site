import pytest


@pytest.mark.parametrize("mode", ["local_fake", "dry_run", "pilot_prelaunch",
                                  "pilot_live_restricted", "incident_mode"])
def test_outbound_blocked_in_every_mode(harness, req_factory, mode):
    resp = harness.process_request(req_factory(
        mode=mode, message="text customer their order is ready",
        tool="send_text_message", approval=True))
    assert resp.allowed is False


def test_real_system_change_blocked(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="dry_run", message="change payroll for the team",
        tool="change_payroll", approval=True))
    assert resp.allowed is False
    assert resp.blocked_reason == "outbound_or_real_system_always_blocked"


def test_unknown_intent_deny_by_default(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="dry_run", message="zzz unmapped gibberish", tool=None))
    assert resp.allowed is False
    assert resp.blocked_reason == "unknown_intent_deny_by_default"
