import pytest


@pytest.mark.parametrize("message,tool", [
    ("show me the store profile", "read_store_profile"),
    ("create a shift note", "create_shift_note"),
    ("mark pilot ready", "mark_pilot_ready"),
    ("text customer", "send_text_message"),
])
def test_human_only_blocks_everything(harness, req_factory, message, tool):
    resp = harness.process_request(req_factory(
        mode="human_only", message=message, tool=tool, approval=True))
    assert resp.allowed is False
    assert resp.blocked_reason == "human_only_mode_active"
    assert "uman review" in resp.final_message
    assert resp.fake_tool_result is None


def test_human_only_governance_flag_blocks(req_factory):
    from mcpherson_runtime_harness import RuntimeHarness
    h = RuntimeHarness(governance_state={"human_only": True})
    resp = h.process_request(req_factory(mode="dry_run"))
    assert resp.allowed is False
