def test_runtime_processes_fake_request(harness, req_factory):
    resp = harness.process_request(req_factory())
    assert resp.request_id.startswith("req-")
    assert resp.mode == "local_fake"
    assert resp.intent == "safe_read"
    assert resp.trace_event is not None
    assert resp.fictional_marker == "SAMPLE ONLY — FICTIONAL — NOT REAL CLIENT DATA"
