def test_kill_switch_blocks_writes(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="dry_run", message="create a shift note",
        tool="create_shift_note", kill=True))
    assert resp.allowed is False
    assert resp.blocked_reason == "kill_switch_blocks_memory_write"


def test_kill_switch_does_not_block_reads(harness, req_factory):
    resp = harness.process_request(req_factory(
        mode="dry_run", message="show me the store profile",
        tool="read_store_profile", kill=True))
    assert resp.allowed is True
