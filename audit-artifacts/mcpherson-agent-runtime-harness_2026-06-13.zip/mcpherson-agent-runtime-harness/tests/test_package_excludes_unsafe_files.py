"""Verify the package script's exclusion list covers unsafe paths."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from package_runtime_harness_zip import EXCLUDED, is_excluded  # noqa: E402


def test_exclusion_list_covers_required_patterns():
    required = {".env", "__pycache__", "dist", "exports", "backups",
                "secrets", "client_data", "logs", "fake_output",
                ".git", ".pytest_cache", ".DS_Store"}
    assert required.issubset(EXCLUDED)


def test_is_excluded_behavior():
    assert is_excluded(Path(".env"))
    assert is_excluded(Path(".env.local"))
    assert is_excluded(Path("src/__pycache__/x.pyc"))
    assert is_excluded(Path("a/b.pyc"))
    assert is_excluded(Path("a/b.pyo"))
    assert is_excluded(Path("data/store.db"))
    assert is_excluded(Path("data/store.sqlite"))
    assert is_excluded(Path("data/store.sqlite3"))
    assert is_excluded(Path(".DS_Store"))
    assert is_excluded(Path("secrets/key.txt"))
    assert is_excluded(Path("client_data/file.json"))
    assert not is_excluded(Path("README.md"))
    assert not is_excluded(Path("src/mcpherson_runtime_harness/runtime.py"))
    assert not is_excluded(Path(".env.example"))
