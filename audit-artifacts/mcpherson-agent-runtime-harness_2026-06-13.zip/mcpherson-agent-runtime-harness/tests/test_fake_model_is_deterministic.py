from mcpherson_runtime_harness.fake_model import fake_model_plan


def test_fake_model_is_deterministic():
    msg = "create a shift note about prep"
    a = fake_model_plan(msg)
    b = fake_model_plan(msg)
    assert a == b
    assert a["external_call"] is False


def test_fake_model_known_mappings():
    assert fake_model_plan("show the profile")["intent"] == "safe_read"
    assert fake_model_plan("shift note please")["intent"] == "fake_memory_write"
    assert fake_model_plan("add a follow up")["intent"] == "fake_memory_write"
    assert fake_model_plan("mark pilot ready")["intent"] == "approval_required"
    assert fake_model_plan("text customer now")["intent"] == "outbound_action"
    assert fake_model_plan("update payroll")["intent"] == "real_system_change"
    assert fake_model_plan("zzz gibberish")["intent"] == "unknown"
