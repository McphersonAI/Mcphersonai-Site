"""Deterministic fake model placeholder.

This NEVER calls a real AI model, network, or external API. It maps
incoming messages to fixed plan strings so the runtime is testable
without external dependencies.
"""

from .intent_classifier import classify_intent
from .models import (
    INTENT_SAFE_READ,
    INTENT_FAKE_MEMORY_WRITE,
    INTENT_APPROVAL_REQUIRED,
    INTENT_OUTBOUND_ACTION,
    INTENT_REAL_SYSTEM_CHANGE,
    FICTIONAL_MARKER,
)

_PLAN_TEXT = {
    INTENT_SAFE_READ: "This looks like a safe read request.",
    INTENT_FAKE_MEMORY_WRITE: "This looks like a shift note or follow-up request.",
    INTENT_APPROVAL_REQUIRED: "This looks like an approval-required action.",
    INTENT_OUTBOUND_ACTION: "This looks like an unsafe outbound action.",
    INTENT_REAL_SYSTEM_CHANGE: "This looks like a real-system change and must be blocked.",
}

_DEFAULT_PLAN = "This request is unrecognized. Draft-only response; no execution."


def fake_model_plan(message: str) -> dict:
    """Return a deterministic fake plan for a message. Same input, same output."""
    intent = classify_intent(message)
    return {
        "plan_text": _PLAN_TEXT.get(intent, _DEFAULT_PLAN),
        "intent": intent,
        "model": "fake-deterministic-placeholder-v0.1",
        "external_call": False,
        "fictional_marker": FICTIONAL_MARKER,
    }
