"""Safe response builder. Every response satisfies the response contract."""

from .models import RuntimeResponse, DECISION_ALLOWED, DECISION_BLOCKED


def build_response(*, request, intent: str, allowed: bool,
                   blocked_reason: str | None, fake_tool_result,
                   trace_event: dict, final_message: str) -> RuntimeResponse:
    return RuntimeResponse(
        request_id=request.request_id,
        fake_pilot_id=request.fake_pilot_id,
        mode=request.mode,
        intent=intent,
        allowed=allowed,
        blocked_reason=None if allowed else (blocked_reason or "deny_by_default"),
        requested_tool=request.requested_tool,
        fake_tool_result=fake_tool_result if allowed else None,
        trace_event=trace_event,
        final_message=final_message,
    )


def decision_label(allowed: bool) -> str:
    return DECISION_ALLOWED if allowed else DECISION_BLOCKED
