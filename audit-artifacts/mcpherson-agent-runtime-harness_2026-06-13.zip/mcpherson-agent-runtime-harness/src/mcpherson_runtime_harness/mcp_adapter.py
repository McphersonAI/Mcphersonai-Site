"""Fake MCP tool decision adapter (local only).

Simulates the MCP Tool Registry decision step. v0.1 uses a local fake
decision set loaded from data/fake_mcp_decisions.json. It never imports
or contacts a live MCP server. Deny by default: an unregistered tool is
always blocked.
"""

from .models import McpDecision
from . import safety

# Built-in default decision set, mirrored by data/fake_mcp_decisions.json.
DEFAULT_MCP_DECISIONS = {
    "read_store_profile": {
        "category": "read",
        "allowed_modes": ["local_fake", "dry_run", "pilot_prelaunch",
                          "pilot_live_restricted", "incident_mode"],
        "approval_required": False,
        "always_blocked": False,
        "incident_read_only": True,
    },
    "read_shift_notes": {
        "category": "read",
        "allowed_modes": ["local_fake", "dry_run", "pilot_prelaunch",
                          "pilot_live_restricted", "incident_mode"],
        "approval_required": False,
        "always_blocked": False,
        "incident_read_only": True,
    },
    "create_shift_note": {
        "category": "write",
        "allowed_modes": ["local_fake", "dry_run", "pilot_prelaunch",
                          "pilot_live_restricted"],
        "approval_required": False,
        "always_blocked": False,
    },
    "create_followup": {
        "category": "write",
        "allowed_modes": ["local_fake", "dry_run", "pilot_prelaunch",
                          "pilot_live_restricted"],
        "approval_required": False,
        "always_blocked": False,
    },
    "create_proof_event": {
        "category": "write",
        "allowed_modes": ["local_fake", "dry_run", "pilot_prelaunch",
                          "pilot_live_restricted"],
        "approval_required": False,
        "always_blocked": False,
    },
    "mark_pilot_ready": {
        "category": "approval_required",
        "allowed_modes": ["dry_run", "pilot_prelaunch", "pilot_live_restricted"],
        "approval_required": True,
        "always_blocked": False,
    },
    "send_text_message": {
        "category": "outbound",
        "allowed_modes": [],
        "approval_required": True,
        "always_blocked": True,
    },
    "change_payroll": {
        "category": "real_system",
        "allowed_modes": [],
        "approval_required": True,
        "always_blocked": True,
    },
}


def evaluate_tool(requested_tool: str | None, mode: str,
                  approval_present: bool,
                  decisions: dict | None = None) -> McpDecision:
    table = decisions or DEFAULT_MCP_DECISIONS

    if not requested_tool:
        return McpDecision(False, "no_tool_requested", tool_exists=False)

    entry = table.get(requested_tool)
    if entry is None:
        return McpDecision(False, "tool_not_registered", tool_exists=False)

    if entry.get("always_blocked"):
        return McpDecision(False, "tool_always_blocked",
                           approval_required=entry.get("approval_required", False))

    rules = safety.mode_rules(mode)
    if rules.get("blocks_everything"):
        return McpDecision(False, "mode_blocks_all_tools")

    if mode not in entry.get("allowed_modes", []):
        return McpDecision(False, "tool_not_allowed_in_mode")

    if rules.get("incident_read_only") and not entry.get("incident_read_only"):
        return McpDecision(False, "incident_mode_read_only")

    if entry.get("category") == "write" and rules.get("writes_need_policy"):
        if not entry.get("policy_permitted_in_restricted", True):
            return McpDecision(False, "write_not_policy_permitted")

    if entry.get("approval_required") and not approval_present:
        return McpDecision(False, "approval_required_not_present",
                           approval_required=True)

    return McpDecision(True, "tool_allowed",
                       approval_required=entry.get("approval_required", False))
