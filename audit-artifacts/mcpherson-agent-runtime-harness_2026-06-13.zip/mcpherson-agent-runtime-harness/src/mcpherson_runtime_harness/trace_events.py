"""Trace-style event creation (local only).

Creates trace-shaped dictionaries for every runtime request. Does NOT
call Langfuse or any network endpoint. A future module may forward
these events to the audited Langfuse Observability Layer.
"""

import uuid
from datetime import datetime, timezone

from .models import FICTIONAL_MARKER


def build_trace_event(*, request_id: str, fake_pilot_id: str, mode: str,
                      intent: str, requested_tool: str | None,
                      governance_decision: str, mcp_decision: str,
                      final_decision: str, reason: str,
                      approval_required: bool,
                      approval_present: bool) -> dict:
    return {
        "event_id": f"trace-{uuid.uuid4()}",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "request_id": request_id,
        "fake_pilot_id": fake_pilot_id,
        "mode": mode,
        "intent": intent,
        "requested_tool": requested_tool,
        "governance_decision": governance_decision,
        "mcp_decision": mcp_decision,
        "final_decision": final_decision,
        "reason": reason,
        "approval_required": approval_required,
        "approval_present": approval_present,
        "fictional_marker": FICTIONAL_MARKER,
    }
