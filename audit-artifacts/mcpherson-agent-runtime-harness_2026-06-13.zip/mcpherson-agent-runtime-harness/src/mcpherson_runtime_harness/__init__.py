"""McPherson AI Agent Runtime Harness Scaffold — FAKE ONLY, no live integrations."""

from .models import RuntimeRequest, RuntimeResponse, FICTIONAL_MARKER, VALID_MODES
from .runtime import RuntimeHarness

__all__ = ["RuntimeRequest", "RuntimeResponse", "RuntimeHarness",
           "FICTIONAL_MARKER", "VALID_MODES"]
__version__ = "0.1.0"
