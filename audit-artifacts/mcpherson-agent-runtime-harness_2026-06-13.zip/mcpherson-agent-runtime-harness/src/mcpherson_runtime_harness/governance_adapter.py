"""Fake governance adapter (local only).

Simulates the Governance Layer decision. Future versions integrate with
the audited Governance Layer module; v0.1 evaluates a local fake
governance state dict. Deny by default.
"""

from .models import (
    GovernanceDecision,
    INTENT_SAFE_READ,
    INTENT_FAKE_MEMORY_WRITE,
    INTENT_APPROVAL_REQUIRED,
    MODE_HUMAN_ONLY,
    MODE_INCIDENT,
)
from . import safety

DEFAULT_GOVERNANCE_STATE = {
    "agent_enabled": True,
    "human_only": False,
    "incident_mode": False,
    "allow_memory_reads": True,
    "allow_memory_writes": True,
    "allow_tool_execution": True,
    "allow_outbound_actions": False,  # never true in this scaffold
    "blake_approval_required_for": ["mark_pilot_ready"],
}


def evaluate_governance(intent: str, mode: str, state: dict,
                        approval_present: bool,
                        requested_tool: str | None) -> GovernanceDecision:
    s = {**DEFAULT_GOVERNANCE_STATE, **(state or {})}
    rules = safety.mode_rules(mode)

    if not s.get("agent_enabled", False):
        return GovernanceDecision(False, "agent_disabled")

    if s.get("human_only") or mode == MODE_HUMAN_ONLY or rules.get("blocks_everything"):
        return GovernanceDecision(False, "human_only_mode_active")

    if s.get("incident_mode") or mode == MODE_INCIDENT:
        if intent == INTENT_SAFE_READ and rules.get("reads_allowed"):
            return GovernanceDecision(True, "incident_read_only_allowed")
        return GovernanceDecision(False, "incident_mode_blocks_action")

    if intent == INTENT_SAFE_READ:
        if rules.get("reads_allowed") and s.get("allow_memory_reads"):
            return GovernanceDecision(True, "read_allowed")
        return GovernanceDecision(False, "reads_blocked")

    if intent == INTENT_FAKE_MEMORY_WRITE:
        if rules.get("writes_allowed") and s.get("allow_memory_writes"):
            return GovernanceDecision(True, "write_allowed")
        return GovernanceDecision(False, "writes_blocked")

    if intent == INTENT_APPROVAL_REQUIRED:
        approval_required = (requested_tool or "") in s.get(
            "blake_approval_required_for", []
        ) or True  # approval-required intent always requires approval
        if approval_present:
            return GovernanceDecision(True, "approved_with_fake_approval",
                                      approval_required=True,
                                      approval_present=True)
        return GovernanceDecision(False, "blake_approval_required",
                                  approval_required=True,
                                  approval_present=False)

    # Deny by default for anything else
    return GovernanceDecision(False, "deny_by_default")
