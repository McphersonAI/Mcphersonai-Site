"""Safety rules for the runtime harness. DENY BY DEFAULT.

This module defines what each operating mode permits, the list of
always-blocked action categories, and the strongest overrides
(human_only, incident_mode, kill switch).

Nothing in this module performs any real action. It only decides.
"""

from .models import (
    MODE_LOCAL_FAKE,
    MODE_DRY_RUN,
    MODE_PILOT_PRELAUNCH,
    MODE_PILOT_LIVE_RESTRICTED,
    MODE_HUMAN_ONLY,
    MODE_INCIDENT,
    INTENT_SAFE_READ,
    INTENT_FAKE_MEMORY_WRITE,
    INTENT_APPROVAL_REQUIRED,
    INTENT_OUTBOUND_ACTION,
    INTENT_REAL_SYSTEM_CHANGE,
    INTENT_UNKNOWN,
)

# Categories that are ALWAYS blocked in this scaffold, regardless of mode,
# governance state, or approval. The harness never performs real actions.
ALWAYS_BLOCKED_INTENTS = frozenset({
    INTENT_OUTBOUND_ACTION,      # live texts, emails, SMS, customer contact
    INTENT_REAL_SYSTEM_CHANGE,   # payroll, POS, vendor orders, billing
})

# Unknown intent is never executed. It falls through to a safe draft-only
# blocked response (deny by default).
DENY_BY_DEFAULT_INTENTS = frozenset({INTENT_UNKNOWN})

# Per-mode permission table for FAKE behavior only.
# "writes_need_policy" means the MCP/tool decision set must explicitly
# permit the write tool in that mode.
MODE_RULES = {
    MODE_LOCAL_FAKE: {
        "reads_allowed": True,
        "writes_allowed": True,
        "writes_need_policy": False,
        "approval_enforced": True,   # approval-required tools still need approval
        "outbound_allowed": False,
        "real_integrations_allowed": False,
        "blocks_everything": False,
    },
    MODE_DRY_RUN: {
        "reads_allowed": True,
        "writes_allowed": True,
        "writes_need_policy": False,
        "approval_enforced": True,
        "outbound_allowed": False,
        "real_integrations_allowed": False,
        "blocks_everything": False,
    },
    MODE_PILOT_PRELAUNCH: {
        "reads_allowed": True,
        "writes_allowed": True,
        "writes_need_policy": True,
        "approval_enforced": True,
        "outbound_allowed": False,
        "real_integrations_allowed": False,
        "blocks_everything": False,
    },
    MODE_PILOT_LIVE_RESTRICTED: {
        "reads_allowed": True,
        "writes_allowed": True,
        "writes_need_policy": True,
        "approval_enforced": True,
        "outbound_allowed": False,   # blocked in v0.1
        "real_integrations_allowed": False,  # blocked in v0.1
        "blocks_everything": False,
    },
    MODE_HUMAN_ONLY: {
        "reads_allowed": False,
        "writes_allowed": False,
        "writes_need_policy": True,
        "approval_enforced": True,
        "outbound_allowed": False,
        "real_integrations_allowed": False,
        "blocks_everything": True,   # strongest override
    },
    MODE_INCIDENT: {
        "reads_allowed": True,       # limited incident-read-only reads
        "incident_read_only": True,
        "writes_allowed": False,
        "writes_need_policy": True,
        "approval_enforced": True,
        "outbound_allowed": False,
        "real_integrations_allowed": False,
        "blocks_everything": False,
    },
}


def mode_rules(mode: str) -> dict:
    """Return the rule set for a mode. Unrecognized mode = deny everything."""
    return MODE_RULES.get(mode, {
        "reads_allowed": False,
        "writes_allowed": False,
        "writes_need_policy": True,
        "approval_enforced": True,
        "outbound_allowed": False,
        "real_integrations_allowed": False,
        "blocks_everything": True,
    })


def intent_is_always_blocked(intent: str) -> bool:
    return intent in ALWAYS_BLOCKED_INTENTS


def intent_is_deny_by_default(intent: str) -> bool:
    return intent in DENY_BY_DEFAULT_INTENTS


def kill_switch_blocks(intent: str, kill_switch_active: bool) -> bool:
    """Kill switch blocks all memory writes (simulated SQLite writes)."""
    return bool(kill_switch_active) and intent == INTENT_FAKE_MEMORY_WRITE


SAFE_HUMAN_ONLY_MESSAGE = (
    "Human review is required. This request was not executed because "
    "human_only mode is active. No tools were called, no memory was "
    "written, and no outbound action was taken."
)

SAFE_INCIDENT_MESSAGE = (
    "Incident mode is active. Writes and outbound actions are blocked. "
    "Reactivation requires Blake approval."
)
