"""Agent Runtime Harness — core loop (FAKE ONLY).

Implements the 15-step governed runtime sequence:

 1. Receive a fake operator message
 2. Load fake pilot context
 3. Check current operating mode
 4. Check kill switch state
 5. Check human-only mode
 6. Classify requested intent
 7. Build fake context from allowed memory stubs
 8. Ask fake model placeholder for a draft plan
 9. Identify requested fake tool call
10. Ask MCP Tool Registry (fake adapter) whether tool call is allowed
11. Execute fake tool only if allowed
12. Generate trace-style event
13. Save fake runtime event locally (in-process list)
14. Return safe draft response
15. Never perform real outbound action

Sequence guarantee: mode -> governance -> policy -> approval ->
fake execution -> trace -> response. Deny by default.
"""

from .models import (
    RuntimeRequest,
    VALID_MODES,
    MODE_HUMAN_ONLY,
    MODE_INCIDENT,
    INTENT_SAFE_READ,
)
from . import safety
from .intent_classifier import classify_intent
from .fake_model import fake_model_plan
from .governance_adapter import evaluate_governance
from .mcp_adapter import evaluate_tool
from .memory_adapter import FakeMemoryAdapter, execute_fake_tool
from .trace_events import build_trace_event
from .response_builder import build_response, decision_label


class RuntimeHarness:
    """Processes fake requests through the governed loop. No live actions."""

    def __init__(self, governance_state: dict | None = None,
                 mcp_decisions: dict | None = None,
                 memory: FakeMemoryAdapter | None = None):
        self.governance_state = governance_state or {}
        self.mcp_decisions = mcp_decisions  # None -> adapter defaults
        self.memory = memory or FakeMemoryAdapter()
        self.local_event_log: list[dict] = []  # step 13: local fake event log

    # ------------------------------------------------------------------
    def process_request(self, request: RuntimeRequest):
        """Run one fake request through the full safety sequence."""

        # Steps 1-2: message received; fake pilot context is on the request.
        # Step 3: validate operating mode (unknown mode = deny everything).
        mode_valid = request.mode in VALID_MODES
        rules = safety.mode_rules(request.mode)

        # Step 6: classify intent (deterministic keywords).
        intent = classify_intent(request.incoming_message)

        # Step 8: fake model draft plan (deterministic, no external call).
        plan = fake_model_plan(request.incoming_message)

        # --- Hard overrides, checked before anything can execute ---

        # Step 5: human-only mode is the strongest override.
        if (not mode_valid) or request.mode == MODE_HUMAN_ONLY \
                or self.governance_state.get("human_only") \
                or rules.get("blocks_everything"):
            return self._blocked(request, intent,
                                 reason="human_only_mode_active" if mode_valid
                                 else "unknown_mode_deny_by_default",
                                 governance_decision="blocked",
                                 mcp_decision="not_evaluated",
                                 message=safety.SAFE_HUMAN_ONLY_MESSAGE)

        # Always-blocked categories: outbound + real-system changes.
        if safety.intent_is_always_blocked(intent):
            return self._blocked(request, intent,
                                 reason="outbound_or_real_system_always_blocked",
                                 governance_decision="blocked",
                                 mcp_decision="blocked",
                                 message="This action category is always blocked "
                                         "in the runtime harness. No real "
                                         "outbound action was taken.")

        # Unknown intent: deny by default, safe draft-only response.
        if safety.intent_is_deny_by_default(intent):
            return self._blocked(request, intent,
                                 reason="unknown_intent_deny_by_default",
                                 governance_decision="blocked",
                                 mcp_decision="not_evaluated",
                                 message="Request not recognized. Returning a "
                                         "safe draft-only response with no "
                                         "execution. " + plan["plan_text"])

        # Step 4: kill switch blocks all (fake) memory writes.
        if safety.kill_switch_blocks(intent, request.kill_switch_active):
            return self._blocked(request, intent,
                                 reason="kill_switch_blocks_memory_write",
                                 governance_decision="blocked",
                                 mcp_decision="not_evaluated",
                                 message="Kill switch is active. Memory writes "
                                         "are blocked.")

        # --- Governance check (fake adapter) ---
        gov = evaluate_governance(intent, request.mode, self.governance_state,
                                  request.approval_present,
                                  request.requested_tool)
        if not gov.allowed:
            msg = safety.SAFE_INCIDENT_MESSAGE \
                if request.mode == MODE_INCIDENT and intent != INTENT_SAFE_READ \
                else f"Blocked by governance: {gov.reason}."
            return self._blocked(request, intent, reason=gov.reason,
                                 governance_decision=f"blocked:{gov.reason}",
                                 mcp_decision="not_evaluated",
                                 message=msg,
                                 approval_required=gov.approval_required,
                                 approval_present=gov.approval_present)

        # Steps 9-10: MCP tool decision (fake adapter).
        mcp = evaluate_tool(request.requested_tool, request.mode,
                            request.approval_present, self.mcp_decisions)
        if not mcp.allowed:
            return self._blocked(request, intent, reason=mcp.reason,
                                 governance_decision=f"allowed:{gov.reason}",
                                 mcp_decision=f"blocked:{mcp.reason}",
                                 message=f"Tool blocked by policy: {mcp.reason}.",
                                 approval_required=mcp.approval_required,
                                 approval_present=request.approval_present)

        # Step 7 + 11: build fake context / execute fake tool (allowed only).
        fake_tool_result = execute_fake_tool(request.requested_tool,
                                             self.memory,
                                             request.incoming_message)
        if fake_tool_result is None:
            # No fake executor registered: deny by default.
            return self._blocked(request, intent,
                                 reason="no_fake_executor_deny_by_default",
                                 governance_decision=f"allowed:{gov.reason}",
                                 mcp_decision=f"allowed:{mcp.reason}",
                                 message="No fake executor registered for this "
                                         "tool. Deny by default.")

        # Steps 12-14: trace event, local log, safe draft response.
        trace = build_trace_event(
            request_id=request.request_id,
            fake_pilot_id=request.fake_pilot_id,
            mode=request.mode,
            intent=intent,
            requested_tool=request.requested_tool,
            governance_decision=f"allowed:{gov.reason}",
            mcp_decision=f"allowed:{mcp.reason}",
            final_decision=decision_label(True),
            reason=gov.reason,
            approval_required=mcp.approval_required,
            approval_present=request.approval_present,
        )
        self.local_event_log.append(trace)

        return build_response(
            request=request, intent=intent, allowed=True,
            blocked_reason=None, fake_tool_result=fake_tool_result,
            trace_event=trace,
            final_message=f"[FAKE DRAFT] {plan['plan_text']} "
                          f"Fake tool '{request.requested_tool}' executed "
                          f"in simulation only. No real action was taken.",
        )

    # ------------------------------------------------------------------
    def _blocked(self, request: RuntimeRequest, intent: str, *, reason: str,
                 governance_decision: str, mcp_decision: str, message: str,
                 approval_required: bool = False,
                 approval_present: bool = False):
        trace = build_trace_event(
            request_id=request.request_id,
            fake_pilot_id=request.fake_pilot_id,
            mode=request.mode,
            intent=intent,
            requested_tool=request.requested_tool,
            governance_decision=governance_decision,
            mcp_decision=mcp_decision,
            final_decision=decision_label(False),
            reason=reason,
            approval_required=approval_required,
            approval_present=approval_present,
        )
        self.local_event_log.append(trace)
        return build_response(
            request=request, intent=intent, allowed=False,
            blocked_reason=reason, fake_tool_result=None,
            trace_event=trace, final_message=message,
        )
