"""Fake memory adapter (local only).

Simulates SQLite Memory Layer reads/writes with in-process fake data.
Never opens a database, file handle to a real store, or network socket.
Every result carries the fictional marker.
"""

from .models import FICTIONAL_MARKER

FAKE_STORE_PROFILE = {
    "fake_pilot_id": "pilot-fake-001",
    "store_name": "Sample Bagel Shop #000 (FICTIONAL)",
    "weekly_sales_band": "SAMPLE-BAND-A",
    "open_followups": 2,
    "fictional_marker": FICTIONAL_MARKER,
}

FAKE_SHIFT_NOTES = [
    {"note_id": "note-fake-001", "text": "Sample AM shift note (fictional).",
     "fictional_marker": FICTIONAL_MARKER},
    {"note_id": "note-fake-002", "text": "Sample PM shift note (fictional).",
     "fictional_marker": FICTIONAL_MARKER},
]


class FakeMemoryAdapter:
    """In-memory fake store. Writes only mutate this Python object."""

    def __init__(self):
        self.writes = []

    def read_store_profile(self):
        return dict(FAKE_STORE_PROFILE)

    def read_shift_notes(self):
        return [dict(n) for n in FAKE_SHIFT_NOTES]

    def create_shift_note(self, text: str) -> dict:
        record = {
            "record_type": "shift_note",
            "note_id": f"note-fake-{len(self.writes) + 100}",
            "text": f"[FAKE] {text}",
            "fictional_marker": FICTIONAL_MARKER,
        }
        self.writes.append(record)
        return record

    def create_followup(self, text: str) -> dict:
        record = {
            "record_type": "followup",
            "followup_id": f"fup-fake-{len(self.writes) + 100}",
            "text": f"[FAKE] {text}",
            "fictional_marker": FICTIONAL_MARKER,
        }
        self.writes.append(record)
        return record

    def create_proof_event(self, text: str) -> dict:
        record = {
            "record_type": "proof_event",
            "proof_id": f"proof-fake-{len(self.writes) + 100}",
            "text": f"[FAKE] {text}",
            "fictional_marker": FICTIONAL_MARKER,
        }
        self.writes.append(record)
        return record


TOOL_EXECUTORS = {
    "read_store_profile": lambda mem, msg: mem.read_store_profile(),
    "read_shift_notes": lambda mem, msg: mem.read_shift_notes(),
    "create_shift_note": lambda mem, msg: mem.create_shift_note(msg),
    "create_followup": lambda mem, msg: mem.create_followup(msg),
    "create_proof_event": lambda mem, msg: mem.create_proof_event(msg),
    "mark_pilot_ready": lambda mem, msg: {
        "record_type": "pilot_status",
        "status": "FAKE_PILOT_READY_FLAG_SET",
        "fictional_marker": FICTIONAL_MARKER,
    },
}


def execute_fake_tool(tool: str, memory: FakeMemoryAdapter, message: str):
    """Execute a fake tool ONLY if it has a registered fake executor.
    Outbound / real-system tools have no executor on purpose."""
    executor = TOOL_EXECUTORS.get(tool)
    if executor is None:
        return None
    result = executor(memory, message)
    if isinstance(result, dict):
        result.setdefault("fictional_marker", FICTIONAL_MARKER)
    return result
