"""Deterministic keyword-based intent classifier. No model calls."""

from .models import (
    INTENT_SAFE_READ,
    INTENT_FAKE_MEMORY_WRITE,
    INTENT_APPROVAL_REQUIRED,
    INTENT_OUTBOUND_ACTION,
    INTENT_REAL_SYSTEM_CHANGE,
    INTENT_UNKNOWN,
)

# Ordered rules: first match wins. Most dangerous categories are checked
# first so a message like "text the customer about their profile" is
# classified as an outbound action, not a safe read.
_KEYWORD_RULES = [
    (("payroll", "pos change", "vendor order", "billing"), INTENT_REAL_SYSTEM_CHANGE),
    (("text customer", "text the customer", "send text", "send sms", "email customer"), INTENT_OUTBOUND_ACTION),
    (("pilot ready", "mark pilot"), INTENT_APPROVAL_REQUIRED),
    (("shift note", "follow up", "follow-up", "followup", "proof event"), INTENT_FAKE_MEMORY_WRITE),
    (("profile", "show me", "read", "view"), INTENT_SAFE_READ),
]


def classify_intent(message: str) -> str:
    """Map a fake incoming message to an intent. Unknown defaults to blocked."""
    if not message or not isinstance(message, str):
        return INTENT_UNKNOWN
    text = message.lower()
    for keywords, intent in _KEYWORD_RULES:
        if any(k in text for k in keywords):
            return intent
    return INTENT_UNKNOWN
