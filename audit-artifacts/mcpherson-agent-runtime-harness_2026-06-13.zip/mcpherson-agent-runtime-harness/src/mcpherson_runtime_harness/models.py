"""Core data models and constants for the McPherson AI Agent Runtime Harness.

FAKE-ONLY SCAFFOLD. No live integrations. No real client data. No secrets.
"""

from dataclasses import dataclass, field
from typing import Any, Optional
import uuid

FICTIONAL_MARKER = "SAMPLE ONLY — FICTIONAL — NOT REAL CLIENT DATA"

# Operating modes (ordered roughly by restriction; human_only is strongest override)
MODE_LOCAL_FAKE = "local_fake"
MODE_DRY_RUN = "dry_run"
MODE_PILOT_PRELAUNCH = "pilot_prelaunch"
MODE_PILOT_LIVE_RESTRICTED = "pilot_live_restricted"
MODE_HUMAN_ONLY = "human_only"
MODE_INCIDENT = "incident_mode"

VALID_MODES = [
    MODE_LOCAL_FAKE,
    MODE_DRY_RUN,
    MODE_PILOT_PRELAUNCH,
    MODE_PILOT_LIVE_RESTRICTED,
    MODE_HUMAN_ONLY,
    MODE_INCIDENT,
]

# Intents
INTENT_SAFE_READ = "safe_read"
INTENT_FAKE_MEMORY_WRITE = "fake_memory_write"
INTENT_APPROVAL_REQUIRED = "approval_required"
INTENT_OUTBOUND_ACTION = "outbound_action"
INTENT_REAL_SYSTEM_CHANGE = "real_system_change"
INTENT_UNKNOWN = "unknown"

VALID_INTENTS = [
    INTENT_SAFE_READ,
    INTENT_FAKE_MEMORY_WRITE,
    INTENT_APPROVAL_REQUIRED,
    INTENT_OUTBOUND_ACTION,
    INTENT_REAL_SYSTEM_CHANGE,
    INTENT_UNKNOWN,
]

# Final decisions
DECISION_ALLOWED = "allowed"
DECISION_BLOCKED = "blocked"


def new_request_id() -> str:
    return f"req-{uuid.uuid4()}"


@dataclass
class RuntimeRequest:
    """A fake incoming operator request. All fields are fictional."""

    fake_pilot_id: str
    fake_store_name: str
    fake_operator_role: str
    incoming_message: str
    mode: str
    kill_switch_active: bool = False
    requested_tool: Optional[str] = None
    approval_present: bool = False
    request_id: str = field(default_factory=new_request_id)
    fictional_marker: str = FICTIONAL_MARKER


@dataclass
class GovernanceDecision:
    allowed: bool
    reason: str
    approval_required: bool = False
    approval_present: bool = False


@dataclass
class McpDecision:
    allowed: bool
    reason: str
    tool_exists: bool = True
    approval_required: bool = False


@dataclass
class RuntimeResponse:
    """Structured response contract. Every runtime request returns this shape."""

    request_id: str
    fake_pilot_id: str
    mode: str
    intent: str
    allowed: bool
    requested_tool: Optional[str]
    final_message: str
    trace_event: dict
    blocked_reason: Optional[str] = None
    fake_tool_result: Optional[dict] = None
    fictional_marker: str = FICTIONAL_MARKER

    def to_dict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id,
            "fake_pilot_id": self.fake_pilot_id,
            "mode": self.mode,
            "intent": self.intent,
            "allowed": self.allowed,
            "blocked_reason": self.blocked_reason,
            "requested_tool": self.requested_tool,
            "fake_tool_result": self.fake_tool_result,
            "trace_event": self.trace_event,
            "final_message": self.final_message,
            "fictional_marker": self.fictional_marker,
        }
