"""Run all fake scenarios from data/fake_scenarios.json; print pass/fail summary."""
import sys
from _common import RuntimeHarness, load_scenarios, request_from_scenario

h = RuntimeHarness()
passed = failed = 0
for s in load_scenarios():
    resp = h.process_request(request_from_scenario(s))
    expected_allowed = s["expected_decision"] == "allowed"
    intent_ok = resp.intent == s["expected_intent"]
    decision_ok = resp.allowed == expected_allowed
    trace_ok = bool(resp.trace_event)
    ok = intent_ok and decision_ok and trace_ok
    passed += ok
    failed += (not ok)
    status = "PASS" if ok else "FAIL"
    print(f"{status}  {s['scenario_id']:<55} intent={resp.intent:<20} "
          f"decision={'allowed' if resp.allowed else 'blocked'}")

print(f"\n{passed} passed, {failed} failed, "
      f"{len(h.local_event_log)} trace events generated (all local, all fake).")
sys.exit(1 if failed else 0)
