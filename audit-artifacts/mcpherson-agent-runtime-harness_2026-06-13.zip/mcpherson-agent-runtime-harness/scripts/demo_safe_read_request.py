"""Demo: one safe fake read request."""
from _common import RuntimeHarness, RuntimeRequest, print_response

h = RuntimeHarness()
resp = h.process_request(RuntimeRequest(
    fake_pilot_id="pilot-fake-001",
    fake_store_name="Sample Bagel Shop #000 (FICTIONAL)",
    fake_operator_role="gm",
    incoming_message="show me the store profile",
    mode="local_fake",
    requested_tool="read_store_profile"))
print_response(resp, "Safe fake read request (local_fake)")
