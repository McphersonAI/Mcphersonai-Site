"""Shared helpers for demo scripts. Local only, fake only."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from mcpherson_runtime_harness import RuntimeHarness, RuntimeRequest  # noqa: E402


def load_scenarios():
    return json.loads((ROOT / "data" / "fake_scenarios.json").read_text())["scenarios"]


def request_from_scenario(s):
    return RuntimeRequest(
        fake_pilot_id=s["fake_pilot_id"],
        fake_store_name="Sample Bagel Shop #000 (FICTIONAL)",
        fake_operator_role="gm",
        incoming_message=s["incoming_message"],
        mode=s["mode"],
        requested_tool=s.get("requested_tool"),
        approval_present=s.get("approval_present", False),
        kill_switch_active=s.get("kill_switch_active", False),
    )


def print_response(resp, title=""):
    if title:
        print(f"\n=== {title} ===")
    print(json.dumps(resp.to_dict(), indent=2, ensure_ascii=False, default=str))
