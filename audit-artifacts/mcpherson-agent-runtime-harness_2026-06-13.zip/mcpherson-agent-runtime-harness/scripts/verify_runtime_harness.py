"""Verify the runtime harness repo: required files, fictional markers,
no secrets, no real data, no live-integration imports. Exit 0 = pass."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FAILS = []


def check(label, ok):
    print(f"{'PASS' if ok else 'FAIL'}  {label}")
    if not ok:
        FAILS.append(label)


def main():
    manifest = json.loads((ROOT / "data" / "required_sections.json").read_text())

    for group in ("required_root", "required_docs", "required_data", "required_source"):
        for rel in manifest[group]:
            check(f"exists: {rel}", (ROOT / rel).is_file())

    # Required scenarios
    scenarios = json.loads((ROOT / "data" / "fake_scenarios.json").read_text())["scenarios"]
    ids = {s["scenario_id"] for s in scenarios}
    required_ids = {
        "safe_read_store_profile", "create_fake_shift_note", "create_fake_followup",
        "approval_required_mark_pilot_ready_without_approval",
        "approval_required_mark_pilot_ready_with_fake_approval",
        "blocked_real_text_message", "human_only_blocks_safe_read",
        "incident_mode_blocks_write", "kill_switch_blocks_sqlite_write",
        "trace_event_for_blocked_request",
    }
    check("all 10 required scenarios present", required_ids.issubset(ids))
    check("all scenarios marked fictional",
          all("FICTIONAL" in s.get("fictional_marker", "") for s in scenarios))
    check("scenarios have required fields",
          all({"scenario_id", "fake_pilot_id", "mode", "incoming_message",
               "expected_intent", "requested_tool", "expected_decision",
               "fictional_marker"} <= set(s) for s in scenarios))

    # Data files marked fictional
    for p in (ROOT / "data").glob("*.json"):
        check(f"fictional marker in data/{p.name}", "FICTIONAL" in p.read_text())

    # No secrets
    secret_pats = [re.compile(r"sk-[A-Za-z0-9]{20,}"), re.compile(r"AKIA[0-9A-Z]{16}"),
                   re.compile(r"ghp_[A-Za-z0-9]{30,}"),
                   re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")]
    clean = True
    for p in ROOT.rglob("*"):
        if p.is_file() and p.suffix in {".py", ".json", ".md", ".example"} \
                and not (set(p.parts) & {".git", "__pycache__", ".pytest_cache",
                                         "dist", "exports"}):
            text = p.read_text(errors="ignore")
            if any(pat.search(text) for pat in secret_pats):
                clean = False
    check("no secret-shaped strings in repo", clean)

    # No live integration imports in source
    src = ROOT / "src" / "mcpherson_runtime_harness"
    forbidden = re.compile(
        r"^\s*(import|from)\s+(requests|httpx|aiohttp|socket|telegram|sqlite3|"
        r"langfuse|anthropic|openai|mcp)\b", re.MULTILINE)
    check("no live-integration imports in src",
          not any(forbidden.search(p.read_text()) for p in src.rglob("*.py")))

    # .env.example has no values
    env_ok = True
    for line in (ROOT / ".env.example").read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            if line.split("=", 1)[1].strip() not in ("", '""', "''"):
                env_ok = False
    check(".env.example contains no real values", env_ok)

    print(f"\n{'ALL CHECKS PASSED' if not FAILS else f'{len(FAILS)} CHECKS FAILED'}")
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()
