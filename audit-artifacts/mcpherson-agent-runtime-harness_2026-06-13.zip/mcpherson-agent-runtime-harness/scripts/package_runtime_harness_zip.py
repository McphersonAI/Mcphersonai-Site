"""Package the repo into a clean zip, excluding unsafe/transient files."""
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Directory or file names excluded anywhere in the tree.
EXCLUDED = {
    ".env", "__pycache__", "dist", "exports", "backups", "secrets",
    "client_data", "logs", "fake_output", ".git", ".pytest_cache", ".DS_Store",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".db", ".sqlite", ".sqlite3"}


def is_excluded(rel: Path) -> bool:
    for part in rel.parts:
        if part in EXCLUDED:
            return True
        # .env.* (but keep .env.example)
        if part.startswith(".env") and part != ".env.example":
            return True
    return rel.suffix in EXCLUDED_SUFFIXES


def main():
    dist = ROOT / "dist"
    dist.mkdir(exist_ok=True)
    zip_name = f"mcpherson-agent-runtime-harness_{date.today().isoformat()}.zip"
    zip_path = dist / zip_name
    included = skipped = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(ROOT.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(ROOT)
            if is_excluded(rel):
                skipped += 1
                continue
            zf.write(p, Path("mcpherson-agent-runtime-harness") / rel)
            included += 1
    print(f"Packaged {included} files ({skipped} excluded) -> {zip_path}")


if __name__ == "__main__":
    main()
