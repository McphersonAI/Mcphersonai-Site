"""Demo: approval-required request blocked without approval, allowed with it."""
from _common import RuntimeHarness, RuntimeRequest, print_response

h = RuntimeHarness()
base = dict(fake_pilot_id="pilot-fake-001",
            fake_store_name="Sample Bagel Shop #000 (FICTIONAL)",
            fake_operator_role="gm",
            incoming_message="mark pilot ready for launch",
            mode="dry_run", requested_tool="mark_pilot_ready")

print_response(h.process_request(RuntimeRequest(**base, approval_present=False)),
               "Approval-required WITHOUT approval (expected: blocked)")
print_response(h.process_request(RuntimeRequest(**base, approval_present=True)),
               "Approval-required WITH fake approval (expected: allowed)")
