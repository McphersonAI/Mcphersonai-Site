"""Demo: one fake write request in dry_run mode."""
from _common import RuntimeHarness, RuntimeRequest, print_response

h = RuntimeHarness()
resp = h.process_request(RuntimeRequest(
    fake_pilot_id="pilot-fake-001",
    fake_store_name="Sample Bagel Shop #000 (FICTIONAL)",
    fake_operator_role="gm",
    incoming_message="create a shift note about morning prep",
    mode="dry_run",
    requested_tool="create_shift_note"))
print_response(resp, "Fake write request (dry_run)")
