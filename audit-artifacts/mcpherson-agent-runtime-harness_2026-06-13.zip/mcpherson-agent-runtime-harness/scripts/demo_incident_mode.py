"""Demo: incident_mode blocks writes and outbound actions."""
from _common import RuntimeHarness, RuntimeRequest, print_response

h = RuntimeHarness()
cases = [
    ("Incident write (expected: blocked)",
     dict(incoming_message="create a shift note", requested_tool="create_shift_note")),
    ("Incident outbound (expected: blocked)",
     dict(incoming_message="text customer", requested_tool="send_text_message")),
    ("Incident read-only safe read (expected: allowed)",
     dict(incoming_message="show me the store profile", requested_tool="read_store_profile")),
]
for title, kw in cases:
    resp = h.process_request(RuntimeRequest(
        fake_pilot_id="pilot-fake-001",
        fake_store_name="Sample Bagel Shop #000 (FICTIONAL)",
        fake_operator_role="gm", mode="incident_mode", **kw))
    print_response(resp, title)
