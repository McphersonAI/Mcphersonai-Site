"""Export fake scenarios and example responses into exports/ (local only)."""
import json
from pathlib import Path
from _common import ROOT, RuntimeHarness, load_scenarios, request_from_scenario

exports = ROOT / "exports"
exports.mkdir(exist_ok=True)

h = RuntimeHarness()
out = []
for s in load_scenarios():
    resp = h.process_request(request_from_scenario(s))
    out.append({"scenario": s, "example_response": resp.to_dict()})

path = exports / "runtime_scenarios_with_responses.json"
path.write_text(json.dumps(
    {"fictional_marker": "SAMPLE ONLY — FICTIONAL — NOT REAL CLIENT DATA",
     "results": out}, indent=2, ensure_ascii=False, default=str))
print(f"Exported {len(out)} scenarios with example responses to {path}")
print("Note: exports/ is excluded from the package zip.")
