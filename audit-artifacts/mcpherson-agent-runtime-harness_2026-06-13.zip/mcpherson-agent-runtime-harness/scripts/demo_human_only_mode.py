"""Demo: human_only mode blocks all sample requests."""
from _common import RuntimeHarness, load_scenarios, request_from_scenario, print_response

h = RuntimeHarness()
for s in load_scenarios():
    s = {**s, "mode": "human_only"}
    resp = h.process_request(request_from_scenario(s))
    status = "BLOCKED" if not resp.allowed else "!! ALLOWED (unexpected) !!"
    print(f"{s['scenario_id']:<55} {status}")
print("\nhuman_only mode: all execution blocked. Human review required.")
