# Fake MCP / Tool Decision Adapter

`mcp_adapter.py` simulates the MCP Tool Registry decision step. It does not
import or contact a live MCP server. For each requested tool it evaluates:

- does the tool exist in the fake decision set? (unregistered = blocked)
- is the tool allowed in the current mode?
- is the tool always-blocked (outbound / real-system categories)?
- does approval exist if approval is required?
- incident mode: is the tool flagged `incident_read_only`?

The decision set lives in `data/fake_mcp_decisions.json` (mirrored by
in-code defaults). The runtime's job is to ask: *can this tool be called in
this mode with this approval state?* The registry's job is to answer:
*allowed or blocked, and why.*

## Future integration

Future versions may import the real audited MCP Tool Registry module
through the same `evaluate_tool(...) -> McpDecision` seam. v0.1 is a local
fake adapter only.
