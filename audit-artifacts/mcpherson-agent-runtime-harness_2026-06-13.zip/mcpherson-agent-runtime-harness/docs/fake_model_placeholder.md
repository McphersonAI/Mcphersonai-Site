# Fake Model Placeholder

`fake_model.py` never calls a real AI model, network, or external API. It
maps incoming messages to fixed plan strings via the deterministic intent
classifier, so the same input always produces the same output.

Example mappings:

| Message contains | Intent | Plan text |
|---|---|---|
| "profile" | safe_read | "This looks like a safe read request." |
| "shift note" | fake_memory_write | "This looks like a shift note or follow-up request." |
| "follow up" | fake_memory_write | (same as above) |
| "pilot ready" | approval_required | "This looks like an approval-required action." |
| "text customer" | outbound_action | "This looks like an unsafe outbound action." |
| "payroll" | real_system_change | "This looks like a real-system change and must be blocked." |

## Why no real model calls

Determinism keeps every test reproducible without API keys or network
access, with zero cost and zero blast radius. Choosing a real model
provider is a deferred decision (`deferred_decisions.md`) that requires
its own audit before integration.
