# Scenario Catalog

Ten fake scenarios in `data/fake_scenarios.json`, runnable via
`python scripts/demo_runtime_scenarios.py`:

| # | scenario_id | Mode | Expected |
|---|---|---|---|
| 1 | `safe_read_store_profile` | local_fake | allowed |
| 2 | `create_fake_shift_note` | dry_run | allowed |
| 3 | `create_fake_followup` | dry_run | allowed |
| 4 | `approval_required_mark_pilot_ready_without_approval` | dry_run | blocked |
| 5 | `approval_required_mark_pilot_ready_with_fake_approval` | dry_run | allowed |
| 6 | `blocked_real_text_message` | dry_run | blocked (always) |
| 7 | `human_only_blocks_safe_read` | human_only | blocked |
| 8 | `incident_mode_blocks_write` | incident_mode | blocked |
| 9 | `kill_switch_blocks_sqlite_write` | dry_run + kill switch | blocked |
| 10 | `trace_event_for_blocked_request` | dry_run | blocked, trace generated |

Every scenario carries: `scenario_id`, `fake_pilot_id`, `mode`,
`incoming_message`, `expected_intent`, `requested_tool`,
`expected_decision`, `fictional_marker`.
