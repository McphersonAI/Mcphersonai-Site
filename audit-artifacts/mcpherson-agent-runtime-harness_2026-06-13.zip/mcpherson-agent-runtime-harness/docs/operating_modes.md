# Operating Modes

| Mode | Fake reads | Fake writes | Approval-required | Outbound | Real integrations |
|---|---|---|---|---|---|
| `local_fake` | allowed | allowed | needs approval | blocked | blocked |
| `dry_run` | allowed | allowed | needs fake approval | blocked | blocked |
| `pilot_prelaunch` | allowed | need policy permission | needs fake approval | blocked | blocked |
| `pilot_live_restricted` | allowed | need policy permission | needs approval | blocked (v0.1) | blocked (v0.1) |
| `human_only` | **blocked** | **blocked** | **blocked** | blocked | blocked |
| `incident_mode` | incident-read-only only | **blocked** | **blocked** | blocked | blocked |

## human_only — strongest override

When active (by mode or governance flag), the runtime does not execute
tools, does not write memory, and returns a safe message stating that
human review is required. Nothing else can override it.

## incident_mode

Limited safe reads may be allowed for incident review (tools flagged
`incident_read_only` in the MCP decision set). Writes, other tool calls,
and outbound actions are blocked. Reactivation is blocked until Blake
approval.

## Unrecognized modes

Any mode string not in the table is treated as deny-everything.
