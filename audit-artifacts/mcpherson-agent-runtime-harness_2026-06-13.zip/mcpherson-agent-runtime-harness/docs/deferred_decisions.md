# Deferred Decisions

Deliberately not decided in v0.1:

1. **Real model provider** — which model powers the live runtime, and the
   prompt/caching strategy around it.
2. **Live Telegram interface** — bot architecture, auth, and rate limits.
3. **Real MCP registry import** — when and how the audited MCP Tool
   Registry replaces the fake adapter.
4. **SQLite write integration** — schema ownership and migration path from
   fake memory records.
5. **Langfuse trace submission** — which module forwards local trace
   events, batching, and redaction policy.
6. **App / console connector** — any operator UI beyond chat.
7. **Multi-store runtime permissions** — how mode and policy vary per
   store under one operator.
8. **Per-client isolation** — droplet-per-client vs shared runtime, and
   the least-privilege allowlist each client receives.
9. **Production hosting model** — where the live runtime runs and how it
   is monitored (relates to the existing liveness runbook work).

Each item requires its own design doc, audit, and Blake approval before
implementation.
