# Integration Boundaries

This repo contains **no live integrations**:

- No live Telegram (no `telegram`/`telethon` imports, no bot tokens).
- No OpenClaw connection of any kind.
- No live MCP server (the MCP adapter is a local fake decision table).
- No live SQLite (no `sqlite3` import, no `.db`/`.sqlite` files; the
  package script excludes them defensively).
- No live Langfuse (trace events are local dictionaries only).
- No real model calls (the model is a deterministic placeholder).
- No network code at all: tests assert that `requests`, `httpx`,
  `aiohttp`, `socket`, and similar modules are never imported in `src/`,
  and that no URLs appear in source.

These boundaries are enforced three ways: code review rules in
`CLAUDE.md`, automated checks in `tests/test_no_live_integrations.py`, and
`scripts/verify_runtime_harness.py`.
