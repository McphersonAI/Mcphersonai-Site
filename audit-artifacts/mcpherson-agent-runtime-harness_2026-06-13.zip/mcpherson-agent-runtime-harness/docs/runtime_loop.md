# The 15-Step Runtime Loop

1. **Receive** a fake operator message.
2. **Load** fake pilot context (pilot id, store name, operator role).
3. **Check** current operating mode (unknown mode = deny everything).
4. **Check** kill switch state (active = all memory writes blocked).
5. **Check** human-only mode (active = everything blocked, strongest override).
6. **Classify** requested intent (deterministic keyword matching).
7. **Build** fake context from allowed memory stubs.
8. **Ask** the fake model placeholder for a draft plan (deterministic).
9. **Identify** the requested fake tool call.
10. **Ask** the (fake) MCP Tool Registry whether the tool call is allowed.
11. **Execute** the fake tool only if allowed.
12. **Generate** a trace-style event (allowed and blocked requests alike).
13. **Save** the fake runtime event locally (`harness.local_event_log`).
14. **Return** a safe draft response satisfying the response contract.
15. **Never** perform a real outbound action.

Guaranteed sequence:
`mode → governance → policy → approval → fake execution → trace → response`

Implementation: `src/mcpherson_runtime_harness/runtime.py`,
`RuntimeHarness.process_request()`.
