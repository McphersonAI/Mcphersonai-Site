# Fake Memory Adapter

`memory_adapter.py` simulates the SQLite Memory Layer with in-process fake
data. It never opens a database, file, or socket.

Simulated operations:

- read fake store profile
- read fake shift notes
- create fake shift note
- create fake follow-up
- create fake proof event

Every result includes
`fictional_marker: "SAMPLE ONLY — FICTIONAL — NOT REAL CLIENT DATA"` and
write payload text is prefixed `[FAKE]`. Writes only mutate the in-memory
`FakeMemoryAdapter.writes` list and vanish when the process exits.

Tools without a registered fake executor (e.g., `send_text_message`)
cannot execute even if a policy bug allowed them — deny by default has a
second line of defense at execution time.

## Future integration

The audited SQLite Memory Layer plugs in behind the same adapter surface
after governance approval. v0.1 is fake-only.
