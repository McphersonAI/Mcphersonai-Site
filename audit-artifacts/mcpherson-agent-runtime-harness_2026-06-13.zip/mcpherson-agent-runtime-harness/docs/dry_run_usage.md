# Dry-Run Usage

## Run the test suite

```bash
python -m pytest tests/ -q
```

## Run verification

```bash
python scripts/verify_runtime_harness.py
```

Checks required docs/data/source files, the 10 required scenarios,
fictional markers, secret scanning, live-integration import scanning, and
that `.env.example` carries no values.

## Run demos

```bash
python scripts/demo_safe_read_request.py        # allowed read
python scripts/demo_fake_write_request.py       # allowed fake write (dry_run)
python scripts/demo_approval_required_request.py  # blocked then allowed
python scripts/demo_human_only_mode.py          # everything blocked
python scripts/demo_incident_mode.py            # writes/outbound blocked
python scripts/demo_kill_switch_block.py        # write blocked
python scripts/demo_runtime_scenarios.py        # all 10, pass/fail summary
```

## Export and package

```bash
python scripts/export_runtime_scenarios.py      # writes exports/ (zip-excluded)
python scripts/package_runtime_harness_zip.py   # writes dist/*.zip
```
