# Runtime Architecture (Conceptual)

```
Operator / Chat Input (fake message)
        ↓
Agent Runtime Harness (runtime.py)
        ↓
Fake Governance Adapter (governance_adapter.py)
        ↓
Fake MCP Tool Decision Adapter (mcp_adapter.py)
        ↓
Fake Memory Adapter (memory_adapter.py)
        ↓
Trace Event Shape (trace_events.py)
        ↓
Safe Draft Response (response_builder.py)
```

Each layer answers one question:

- **Runtime**: can this request proceed in this mode with this kill-switch
  state, and in what order do checks run?
- **Governance**: is the agent enabled, is the pilot approved for this
  stage, is human-only or incident mode active, is approval required?
- **MCP adapter**: can this tool be called in this mode with this approval
  state? Allowed or blocked, and why.
- **Memory adapter**: simulate the read/write with fake records only.
- **Trace events**: record the full decision for every request, allowed
  or blocked.
- **Response builder**: return the consistent response contract.

The runtime never duplicates governance or MCP policy — it asks; the
adapters answer. In v0.1 both adapters are local fakes; future versions
import the audited Governance Layer and MCP Tool Registry modules.
