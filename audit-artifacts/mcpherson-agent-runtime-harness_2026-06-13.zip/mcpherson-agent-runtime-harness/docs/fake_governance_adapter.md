# Fake Governance Adapter

`governance_adapter.py` simulates the Governance Layer decision locally.
It evaluates:

- `agent_enabled`
- `current_mode`
- `human_only`
- `incident_mode`
- `allow_memory_reads`
- `allow_memory_writes`
- `allow_tool_execution`
- `allow_outbound_actions` (permanently false in this scaffold)
- `blake_approval_required` / `blake_approval_present`

State is loaded from `data/fake_governance_state.json` or passed directly
to `RuntimeHarness(governance_state=...)`. Anything not explicitly allowed
is denied (`deny_by_default`).

## Future integration

Future versions integrate with the audited Governance Layer module. The
adapter interface (`evaluate_governance(...) -> GovernanceDecision`) is the
seam where the real layer plugs in, after Governance approval and a fresh
audit. v0.1 is fake and local only.
