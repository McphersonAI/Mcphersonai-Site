# Trace Event Model

`trace_events.py` creates a trace-shaped dictionary for **every** runtime
request — allowed or blocked. It does not call Langfuse or any network
endpoint; events are appended to the local `harness.local_event_log` list.

Fields:

- `event_id`
- `timestamp`
- `request_id`
- `fake_pilot_id`
- `mode`
- `intent`
- `requested_tool`
- `governance_decision`
- `mcp_decision`
- `final_decision` (`allowed` / `blocked`)
- `reason`
- `approval_required`
- `approval_present`
- `fictional_marker`

## Future Langfuse integration

A separate, future module may read these trace-shaped dictionaries and
submit them to the audited Langfuse Observability Layer. This repo never
does that itself.
