# Overview

The Agent Runtime Harness Scaffold answers one question: **what happens
between an operator asking something and the agent returning a response?**

It is a private internal scaffold that simulates how a future McPherson AI
agent should process a request safely. It is not a live agent, not a
Telegram bot, not an OpenClaw connection, not a real model call, not a live
MCP server, and not a customer-facing product.

## Boundaries

- Fake data only. Every record carries the fictional marker.
- No network calls of any kind. No secrets required or present.
- Deny by default: unknown intents, unregistered tools, outbound actions,
  and real-system changes are blocked.
- `human_only` mode is the strongest override and blocks all execution.
- The runtime makes agent behavior more **bounded, inspectable, testable,
  and recoverable** — never more autonomous.

## Strategic role

SQLite can store memory. Langfuse can observe. Governance can approve or
block. MCP can define tool permissions. The runtime harness is the traffic
controller that proves the parts work together in one tested flow before
any live system exists.
