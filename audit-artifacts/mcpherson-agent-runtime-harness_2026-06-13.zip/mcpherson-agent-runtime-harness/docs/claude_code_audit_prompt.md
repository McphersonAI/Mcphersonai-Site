# Claude Code Audit Prompt

Copy the prompt below into Claude Code from the repo root.

---

You are auditing the `mcpherson-agent-runtime-harness` repository, a
private internal scaffold that simulates a governed agent runtime loop
with fake data only. Audit it against the following claims and report
PASS/FAIL per item with file/line evidence. Do not modify code during the
audit; produce findings only.

**1. Fake-only runtime behavior.** Confirm the runtime (`src/`) operates
entirely on in-process fake data: no file-backed state beyond reading the
JSON files in `data/`, no databases, no persistence of writes.

**2. No live model calls.** Confirm `fake_model.py` is deterministic and
that no module imports or calls any AI provider SDK or HTTP client.

**3. No live integrations.** Confirm there are no imports of `requests`,
`httpx`, `aiohttp`, `socket`, `telegram`, `sqlite3`, `langfuse`,
`anthropic`, `openai`, or `mcp` in `src/`, and no URLs in source.

**4. Deny-by-default behavior.** Trace `runtime.py` and confirm: unknown
intents are blocked, unregistered tools are blocked, tools without a fake
executor are blocked at execution time, and unrecognized modes deny
everything.

**5. human_only mode.** Confirm it is the strongest override: blocks
reads, writes, tool calls, and outbound actions, whether set by mode or
governance flag, and returns a human-review-required message.

**6. incident_mode.** Confirm writes and outbound actions are blocked,
only `incident_read_only` tools can run, and docs state reactivation
requires Blake approval.

**7. Kill switch.** Confirm an active kill switch blocks all fake memory
writes before governance evaluation, and does not silently allow them in
any mode.

**8. Approval-required behavior.** Confirm `mark_pilot_ready` (and any
approval-required tool) is blocked without approval and allowed only with
explicit approval state, with both outcomes traced.

**9. Trace event shape.** Confirm every request — allowed or blocked —
produces a trace event with all fields listed in
`docs/trace_event_model.md`, appended to the local event log only.

**10. Response contract.** Confirm every response carries all fields in
`docs/response_contract.md`, that blocked responses never include
`fake_tool_result`, and that every response carries the fictional marker.

**11. No secrets.** Scan the full repo for API keys, tokens, private
keys, and credential-shaped strings, and confirm `.env.example` contains
keys without values.

**12. No real client data.** Confirm all data is fictional, marked
`SAMPLE ONLY — FICTIONAL — NOT REAL CLIENT DATA`, and that no real store,
employee, customer, or pilot identifiers appear.

**13. Package exclusions.** Confirm `scripts/package_runtime_harness_zip.py`
excludes `.env`, `.env.*` (except `.env.example`), `__pycache__`, `*.pyc`,
`dist/`, `exports/`, `backups/`, `secrets/`, `client_data/`, `logs/`,
`fake_output/`, `*.db`, `*.sqlite`, `.git`, and `.pytest_cache`.

**14. Test coverage.** Run `python -m pytest tests/ -q` and
`python scripts/verify_runtime_harness.py`; confirm both pass, and assess
whether the tests meaningfully cover items 1–13 above. Flag any safety
claim that lacks a corresponding automated check.

Finish with: (a) an overall PASS/FAIL, (b) a ranked list of any gaps, and
(c) a statement of whether the repo is safe to keep as a fake-only
scaffold. Do not propose adding live integrations.
