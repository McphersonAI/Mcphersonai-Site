# Response Contract

Every runtime response (`RuntimeResponse`, see `models.py` and
`response_builder.py`) includes:

- `request_id`
- `fake_pilot_id`
- `mode`
- `intent`
- `allowed` (bool)
- `blocked_reason` (string if blocked, `null` if allowed)
- `requested_tool`
- `fake_tool_result` (only if allowed; otherwise `null`)
- `trace_event` (full trace event dict)
- `final_message` (safe draft text; never claims a real action happened)
- `fictional_marker`

Invariants enforced by tests:

- blocked responses never carry a `fake_tool_result`
- allowed responses never carry a `blocked_reason`
- every response carries a trace event and the fictional marker
- `final_message` for allowed fake executions states that the action was
  simulation-only
