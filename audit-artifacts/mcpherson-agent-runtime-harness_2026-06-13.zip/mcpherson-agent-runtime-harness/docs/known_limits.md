# Known Limits

- This is **not a live agent** and not a production runtime.
- It is **not connected to real systems** — no POS, payroll, CRM, Telegram,
  OpenClaw, MCP server, SQLite, or Langfuse.
- **Fake data only.** Every record is fictional and marked as such.
- **No secrets** exist or are required.
- **No real client data** exists anywhere in the repo.
- **No external calls** — the process is fully offline and deterministic.
- The intent classifier is keyword-based and intentionally simple; it is a
  stand-in for real classification, not a design commitment.
- The local event log is in-process only and resets per run.
- **Future integration requires a separate audit** for each module
  (model provider, Governance Layer, MCP Tool Registry, SQLite Memory
  Layer, Langfuse) plus Blake approval before anything goes live.
