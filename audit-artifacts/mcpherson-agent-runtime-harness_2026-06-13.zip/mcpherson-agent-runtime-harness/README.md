# McPherson AI — Agent Runtime Harness Scaffold

**Private internal scaffold. Fake data only. No live integrations. No secrets.**

## What this repo is

The Agent Runtime Harness is the controlled loop that will eventually sit
between an operator message and a safe agent response:

```
Operator / Telegram / App Chat
        ↓
Agent Runtime Harness          ← this repo (simulated)
        ↓
Governance Layer               ← fake adapter in v0.1
        ↓
MCP Tool Registry              ← fake adapter in v0.1
        ↓
SQLite / Langfuse / External   ← fake stubs in v0.1
```

It proves the **shape** of the governed agent loop before any live system
exists: every request passes through the same safety sequence —

`mode → governance → policy → approval → fake execution → trace → response`

— and the runtime is **deny by default**.

## What this repo is NOT

- Not a live agent. Not a Telegram bot. Not an OpenClaw connection.
- Not a real model call (the model is a deterministic placeholder).
- Not a live MCP server, live SQLite database, or live Langfuse client.
- Not a production API or customer-facing product.

## How it fits with the other McPherson AI modules

| Module | Relationship in v0.1 |
|---|---|
| Governance Layer | Simulated by `governance_adapter.py`; real layer integrates later after audit |
| MCP Tool Registry | Simulated by `mcp_adapter.py` + `data/fake_mcp_decisions.json` |
| SQLite Memory Layer | Simulated by `memory_adapter.py` (in-process fake records) |
| Langfuse Observability | Trace-shaped local dictionaries only; a future module forwards them |
| Governed Pilot Starter Pack | Shares pilot/mode vocabulary; this repo tests the request flow |
| Pilot Dry-Run / Snapshot Rehearsal | `dry_run` mode here mirrors that rehearsal posture |

## Quick start

```bash
# Run tests
python -m pytest tests/ -q

# Run verification (required files, fictional markers, no secrets, no live imports)
python scripts/verify_runtime_harness.py

# Run individual demos
python scripts/demo_safe_read_request.py
python scripts/demo_fake_write_request.py
python scripts/demo_approval_required_request.py
python scripts/demo_human_only_mode.py
python scripts/demo_incident_mode.py
python scripts/demo_kill_switch_block.py

# Run all 10 fake scenarios with pass/fail summary
python scripts/demo_runtime_scenarios.py

# Export scenarios + example responses to exports/ (excluded from zip)
python scripts/export_runtime_scenarios.py

# Package a clean zip into dist/
python scripts/package_runtime_harness_zip.py
```

Requires Python 3.10+ and `pytest`. No other dependencies. No network.

## Operating modes

`local_fake`, `dry_run`, `pilot_prelaunch`, `pilot_live_restricted`,
`human_only`, `incident_mode`. `human_only` is the strongest override and
blocks everything. See `docs/operating_modes.md`.

## Why no live integrations or real model calls

Live integrations would make this scaffold a live system, which defeats its
purpose: testing the safety sequence in isolation, deterministically, with
zero blast radius. The fake model placeholder keeps every test reproducible
without API keys, network access, or external dependencies. Each real
integration (model provider, Telegram, MCP registry, SQLite, Langfuse) is a
separately audited step — see `docs/deferred_decisions.md`.

## Why Blake approval remains required before live use

The runtime exists to make agent behavior *more* bounded, not more
autonomous. Approval-required actions (e.g., `mark_pilot_ready`) are blocked
without explicit approval state, outbound actions are always blocked in
v0.1, and `incident_mode` reactivation requires Blake approval by design.
Moving any part of this loop to a live deployment requires Governance Layer
sign-off and a fresh Claude Code audit (`docs/claude_code_audit_prompt.md`).

## Repo layout

```
docs/      sixteen design + boundary documents
data/      fake context, scenarios, governance state, MCP decisions, memory records
src/       mcpherson_runtime_harness Python package
scripts/   verify, demos, export, package
tests/     pytest suite (15 test files)
```

All fake data carries the marker:
`SAMPLE ONLY — FICTIONAL — NOT REAL CLIENT DATA`
