# CLAUDE.md — Instructions for Claude Code

Treat this repository as a **private internal scaffold**. It simulates a
governed agent runtime loop with fake data only.

## Hard rules — do not violate

- Do NOT add live AI model calls (no Anthropic, OpenAI, or any API client).
- Do NOT add a live Telegram bot or any chat connector.
- Do NOT add a live OpenClaw connection.
- Do NOT add a live MCP server or MCP client imports.
- Do NOT add live SQLite (no `sqlite3` imports, no `.db` files).
- Do NOT add live Langfuse calls (trace events stay local dictionaries).
- Do NOT add production APIs, webhooks, or network code of any kind.
- Do NOT add real customer, client, store, or employee data.
- Do NOT add secrets, API keys, tokens, or credentials — not even test ones.
- Do NOT weaken deny-by-default behavior anywhere in `src/`.
- Do NOT bypass, soften, or remove Blake-approval requirements.
- Keep this repo fake-data-only, deterministic, and fully testable offline.

## What you may do

- Improve tests, docs, and fake scenarios.
- Refactor for clarity as long as all tests and the verification script pass.
- Add new fake tools to the MCP decision set, defaulting to blocked.

## Verification before finishing any change

```
python scripts/verify_runtime_harness.py
python -m pytest tests/ -q
python scripts/demo_runtime_scenarios.py
```

All three must pass. If a change makes a previously blocked action allowed,
stop and flag it for Blake review instead of committing it.
