# AGENTS.md

## What this repo is for agents

- This repo does **not** run a live agent.
- This repo does **not** connect to external systems: no network, no
  databases, no chat platforms, no model providers, no MCP servers.
- This repo **only simulates** how a future governed McPherson AI agent
  request should flow: mode check → governance → tool policy → approval →
  fake execution → trace event → safe draft response.
- Fake model output is **deterministic** (keyword-mapped placeholder, no
  external calls).
- Future agents may use this runtime shape **only after Governance Layer
  approval** and a separate integration audit.
- All real integrations (model provider, Telegram, OpenClaw, MCP registry,
  SQLite, Langfuse, app connectors) are **deferred** — see
  `docs/deferred_decisions.md`.

## Agent naming context (for reference only)

Spike (operator orchestrator), Spot (insurance), Aegis (renewals), and
Sterling (personal finance) are McPherson AI agents that run elsewhere.
None of them run from or connect to this repo. This scaffold defines the
runtime shape they may eventually adopt, behind governance approval.
